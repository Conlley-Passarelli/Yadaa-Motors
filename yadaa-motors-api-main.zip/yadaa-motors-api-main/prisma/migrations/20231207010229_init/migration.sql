-- CreateTable
CREATE TABLE "Cars" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL
);
